::legacy::set_attribute -quiet library_domain library_domain:slow design:cpu_32bit_top
